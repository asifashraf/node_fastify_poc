module.exports = [
  {
    name: 'GREEN',
    amount: '10.000',
    colorTint: '0DBEAF',
    bonus: '0.000',
    benefits: [],
    sku: '10KD',
  },
  {
    name: 'GOLD',
    amount: '20.000',
    colorTint: 'D3BF39',
    bonus: '0.000',
    benefits: [],
    sku: '20KD',
  },
  {
    name: 'BLACK',
    amount: '30.000',
    colorTint: '000000',
    bonus: '0.000',
    benefits: [],
    sku: '30KD',
  },
];
