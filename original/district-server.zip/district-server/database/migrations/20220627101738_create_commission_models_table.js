exports.up = function (knex) {
  // TODO: IF NEEDED, FIX IT PLS
};    
exports.down = async function (knex) {
  // TODO: IF NEEDED, FIX IT PLS
};