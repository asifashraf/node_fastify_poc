/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('orders', (table) => {
        table.uuid('cofe_customer_id').nullable()
        table.string('cofe_customer_phone').nullable()
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('orders', (table) => {
        table.dropColumn('cofe_customer_id');
        table.dropColumn('cofe_customer_phone');
    })
};
