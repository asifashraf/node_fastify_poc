/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('orders', (table) => {
        table.string('marketplace').nullable()
        table.text('notes').nullable()
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('orders', (table) => {
        table.dropColumn('marketplace');
        table.dropColumn('notes');
    })
};
