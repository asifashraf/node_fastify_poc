const templates =  require('./email/templates')

module.exports = {
    templates
}
