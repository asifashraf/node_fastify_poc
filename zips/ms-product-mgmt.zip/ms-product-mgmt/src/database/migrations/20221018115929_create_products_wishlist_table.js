/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.createTable('products_wishlist', (table) => {
        table.uuid('id').primary();
        table.uuid('id_product').notNullable();
        table.uuid('id_customer').nullable();
    });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.dropTable('products_wishlist');
};
