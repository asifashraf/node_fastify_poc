/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('supplier_bank_details', (table) => {
        table.string('bank', 100)
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('supplier_bank_details', (table) => {
        table.dropColumn('bank')
    })
};
