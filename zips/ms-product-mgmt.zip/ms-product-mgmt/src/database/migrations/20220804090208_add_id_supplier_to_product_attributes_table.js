/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.table('product_attributes', table => {
        table.uuid('id_supplier').notNullable().index();
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.table('product_attributes', table => {
        table.dropColumn('id_supplier');
    })
};
