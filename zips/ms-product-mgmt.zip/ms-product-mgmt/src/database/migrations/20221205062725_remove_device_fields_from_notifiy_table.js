/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = async function (knex) {
    await knex.schema.alterTable('product_notify_when_available', (table) => {
        table.dropColumn('uuid')
        table.dropColumn('device_type')
        table.dropColumn('device_token')
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {

};
