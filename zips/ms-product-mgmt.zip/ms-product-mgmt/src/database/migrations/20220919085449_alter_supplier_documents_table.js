/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('supplier_documents', (table) => {
        table.unique('id_supplier')
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('supplier_documents', (table) => {
        table.dropUnique('id_supplier')
    })
};
