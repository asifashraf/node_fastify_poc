/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('suppliers', (table) => {
        table.string('business_model').defaultTo('Marketplace')
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('suppliers', (table) => {
        table.dropColumn('business_model');
    })
};
