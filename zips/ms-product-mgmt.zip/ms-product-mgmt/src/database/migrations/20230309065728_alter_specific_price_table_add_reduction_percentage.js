/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('product_specific_price', (table) => {
        table.decimal('reduction_percentage', 20, 6).notNullable();
    })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('product_specific_price', (table) => {
        table.dropColumn('reduction_percentage');
    })
};
