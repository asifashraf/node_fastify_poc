module.exports = {
    apps: [
        {
            name: "Foodics Api Container",
            script: "server.js",
            instances: "1"
        }
    ]
}
