const Application = require('./src/app');

Application.bootstrap(process);
